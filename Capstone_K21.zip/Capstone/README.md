# Hack Box

A small Hack computer project: build the computer, write an assembler for it in Python, and run a program that draws a black box on the screen while a key is pressed.

Built on the [Nand to Tetris](https://www.nand2tetris.org/) Hack platform.

## Overview

The project has three parts:

1. **Computer (HDL):** the Hack CPU, memory map and full computer.
2. **Assembler (Python):** turns Hack assembly (`.asm`) into 16-bit machine code (`.hack`).
3. **Box program (assembly):** draws a box while any key is held and clears it when the key is released.

```
Box.asm  --(assembler.py)-->  Box.hack  --(CPU Emulator)-->  box on screen
```

## Box specification

| Property | Value |
|---|---|
| Start row | 10 (rows 10 to 29) |
| Height | 20 rows |
| Width | 48 pixels (3 words) from the left edge |
| First screen address | 16704 (`SCREEN + 32 * 10`) |
| Behavior | Black while a key is pressed, white otherwise |

## Project structure

```
.
├── CPU.hdl         # Hack CPU
├── Memory.hdl      # RAM, Screen and Keyboard memory map
├── Computer.hdl    # ROM + CPU + Memory
├── assembler.py    # Hack assembler
├── Box.asm         # Box program (assembly)
├── Box.hack        # Box program (machine code)
└── README.md
```

## Getting started

### Requirements

- Python 3
- The [Nand to Tetris tools](https://www.nand2tetris.org/software) or the [Web IDE](https://nand2tetris.github.io/web-ide/)

### Assemble a program

```
python assembler.py Box.asm
```

This writes `Box.hack` next to the input file. The assembler works on any Hack `.asm` program, for example `Add.asm`, `Max.asm`, `Rect.asm` and `Pong.asm`.

### Run the box

1. Open the CPU Emulator.
2. Load `Box.hack`.
3. Set the speed to maximum and press Run.
4. Click the keyboard area and hold any key to show the box. Release the key to clear it.

### Test the computer

In the Hardware Simulator, load each chip and run its test file:

| Chip | Test file |
|---|---|
| `CPU.hdl` | `CPU.tst` |
| `Memory.hdl` | `Memory.tst` |
| `Computer.hdl` | `ComputerAdd.tst`, `ComputerMax.tst`, `ComputerRect.tst` |

## How it works

### Assembler

The assembler reads the file twice.

- **First pass:** removes comments and blank lines, and records the address of every label such as `(LOOP)`.
- **Second pass:** translates each line into 16 bits.
  - A-instruction (`@value`): `0` followed by a 15-bit value. New variables get RAM addresses starting at 16.
  - C-instruction: `111` + comp (7 bits) + dest (3 bits) + jump (3 bits).

**Error reporting:** a bad line does not crash the assembler. It prints the line number and the problem, collects all errors, and writes no output file if there are any:

```
Line 3: invalid instruction 'D=X+1' (bad computation 'X+1')
Line 5: invalid jump 'JXX'
Assembly failed with 2 error(s). No .hack file written.
```

### Box program

1. Read the keyboard (address 24576). If it is not 0, set `color` to -1 (black), otherwise to 0 (white).
2. Set `addr` to 16704 and `rows` to 20.
3. For each row, write `color` into 3 words, then add 32 to `addr` to move to the next row.
4. Repeat until all 20 rows are done, then go back to step 1.

One screen row is 32 words and one word is 16 pixels, so row `r` starts at `SCREEN + 32 * r`.

### Computer

- **CPU:** built from the ALU, A register, D register and program counter. The instruction bits control which register loads, which ALU inputs are used, and whether the PC jumps.
- **Memory:** address bit 14 selects RAM (0 to 16383) or the upper area. In the upper area, address bit 13 selects the Screen (16384 to 24575) or the Keyboard (24576).
- **Computer:** ROM32K supplies instructions, the CPU executes them, and Memory handles reads and writes.

The HDL files use the built-in ALU, ARegister, DRegister, PC, RAM16K, Screen, Keyboard and ROM32K chips.